
package com.portfolio.portfolioBackEnd.Security.Entity;

import org.springframework.security.core.userdetails.UserDetails

public class UsuarioPrincipal implements UserDetails{
    
}
