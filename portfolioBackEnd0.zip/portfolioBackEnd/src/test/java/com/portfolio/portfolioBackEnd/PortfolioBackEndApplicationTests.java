package com.portfolio.portfolioBackEnd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PortfolioBackEndApplicationTests {

	@Test
	void contextLoads() {
	}

}
